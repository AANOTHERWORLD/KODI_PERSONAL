\
# -*- coding: utf-8 -*-
import json
import os
import sys
import hashlib
import zipfile
import urllib.request
import urllib.error
import xbmcvfs
import xbmc
import xbmcgui
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
HOME = xbmcvfs.translatePath('special://home/')
TEMP = xbmcvfs.translatePath(os.path.join(PROFILE, 'tmp'))
LOG_PREFIX = f"[{ADDON_NAME}] "

def log(msg):
    xbmc.log(LOG_PREFIX + str(msg), xbmc.LOGINFO)

def notify(title, msg, ms=4000):
    xbmcgui.Dialog().notification(title, msg, time=ms)

def get_setting(key, default=''):
    try:
        val = ADDON.getSetting(key)
        if val is None or val == '':
            return default
        return val
    except Exception:
        return default

def set_setting(key, value):
    try:
        ADDON.setSetting(key, value)
    except Exception as e:
        log(f"Failed to set setting {key}: {e}")

def ensure_dir(path):
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)

def fetch_url(url):
    try:
        with urllib.request.urlopen(url) as resp:
            return resp.read()
    except urllib.error.URLError as e:
        log(f"URL fetch failed: {e}")
        return None

def md5_of_file(path):
    h = hashlib.md5()
    with xbmcvfs.File(path, 'rb') as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()

def extract_zip(zip_path, dest_dir, progress=None):
    with zipfile.ZipFile(zip_path, 'r') as zf:
        items = zf.infolist()
        total = len(items)
        for idx, info in enumerate(items, start=1):
            # Progress UI
            if progress:
                progress.update(int(idx * 100.0 / total), f"Extracting: {info.filename}")
            # Build ZIPs from GitHub include a top-level folder; strip it
            parts = info.filename.split('/', 1)
            rel = parts[1] if len(parts) > 1 else parts[0]
            target = os.path.join(dest_dir, rel)
            if info.is_dir():
                ensure_dir(target)
                continue
            ensure_dir(os.path.dirname(target))
            # Read with xbmcvfs? zipfile uses system file APIs; write via Python stdlib okay
            with zf.open(info) as src, open(target, 'wb') as out:
                out.write(src.read())

def do_install(manifest):
    """
    Install or update the build according to manifest.
    Manifest keys:
      version (str), zip_url (str), md5 (str, optional), changelog (str, optional)
    """
    zip_url = manifest.get('zip_url') or get_setting('build_zip_url')
    expected_md5 = manifest.get('md5') or ''
    new_version = manifest.get('version') or '0.0.0'
    changelog = manifest.get('changelog', '')

    installed_version = get_setting('installed_version', '0.0.0')
    if new_version == installed_version:
        if not xbmcgui.Dialog().yesno(ADDON_NAME, f"Installed version {installed_version} matches manifest.",
                                      "Reinstall anyway?"):
            return

    ensure_dir(TEMP)
    zip_dl_path = os.path.join(TEMP, 'build.zip')

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Downloading build...")
    try:
        # Stream download with progress
        with urllib.request.urlopen(zip_url) as resp, open(zip_dl_path, 'wb') as out:
            total = int(resp.headers.get('Content-Length', '0') or 0)
            read = 0
            block = 1024 * 64
            while True:
                buf = resp.read(block)
                if not buf:
                    break
                out.write(buf)
                read += len(buf)
                if total > 0:
                    percent = int(read * 100.0 / total)
                    progress.update(percent, f"Downloading... {percent}%")
                if progress.iscanceled():
                    raise Exception("Download canceled")
    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, "Download failed", str(e))
        return

    progress.update(0, "Verifying...")
    # Verify MD5 if provided
    if expected_md5:
        actual_md5 = md5_of_file(zip_dl_path)
        if actual_md5.lower() != expected_md5.lower():
            progress.close()
            xbmcgui.Dialog().ok(ADDON_NAME, "MD5 mismatch", f"Expected: {expected_md5}\nActual:   {actual_md5}")
            return

    mode = get_setting('install_mode', '0')
    if mode == '1':
        # Clean mode: very cautious - only clear specific known paths
        if xbmcgui.Dialog().yesno(ADDON_NAME, "Clean install will remove existing addons and userdata.",
                                  "Proceed? This cannot be undone."):
            # Danger: Be conservative; do not delete entire home; only typical build content
            for rel in ('addons', 'userdata/addon_data', 'userdata/keymaps', 'userdata/playlists', 'userdata/profiles'):
                target = os.path.join(HOME, rel)
                try:
                    if xbmcvfs.exists(target):
                        xbmc.executebuiltin(f'XBMC.Notification({ADDON_NAME},Removing {rel},3000)')
                        # Recursively delete
                        xbmcvfs.rmdir(target, force=True)
                except Exception as e:
                    log(f"Failed to clean {rel}: {e}")

    progress.update(0, "Extracting...")
    try:
        extract_zip(zip_dl_path, HOME, progress=progress)
    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, "Extraction failed", str(e))
        return

    progress.close()
    set_setting('installed_version', new_version)
    notify(ADDON_NAME, f"Installed build v{new_version}")
    if changelog:
        xbmcgui.Dialog().textviewer(f"{ADDON_NAME} Changelog", changelog)

def load_manifest():
    url = get_setting('manifest_url')
    raw = fetch_url(url)
    if not raw:
        return None
    try:
        return json.loads(raw.decode('utf-8'))
    except Exception as e:
        log(f"Manifest parse error: {e}")
        return None

def main_menu():
    choices = [
        "Install / Update build",
        "Check for update",
        "Settings",
        "Quit"
    ]
    idx = xbmcgui.Dialog().select(ADDON_NAME, choices)
    if idx == 0:
        manifest = load_manifest()
        if manifest is None:
            if xbmcgui.Dialog().yesno(ADDON_NAME, "Manifest not available.", "Install using fallback ZIP URL?"):
                manifest = {"version": get_setting('installed_version', '0.0.0'),
                            "zip_url": get_setting('build_zip_url'),
                            "md5": ""}
            else:
                return
        do_install(manifest)
    elif idx == 1:
        manifest = load_manifest()
        if manifest is None:
            xbmcgui.Dialog().ok(ADDON_NAME, "Could not load manifest.", "Check the Manifest URL in settings.")
            return
        new_version = manifest.get('version', '0.0.0')
        installed_version = get_setting('installed_version', '0.0.0')
        if new_version > installed_version:
            xbmcgui.Dialog().ok(ADDON_NAME, "Update available",
                                f"Installed: {installed_version}\nAvailable: {new_version}")
        else:
            xbmcgui.Dialog().ok(ADDON_NAME, "No update available",
                                f"Installed: {installed_version}\nAvailable: {new_version}")
    elif idx == 2:
        ADDON.openSettings()
    else:
        return

if __name__ == "__main__":
    ensure_dir(PROFILE)
    main_menu()
