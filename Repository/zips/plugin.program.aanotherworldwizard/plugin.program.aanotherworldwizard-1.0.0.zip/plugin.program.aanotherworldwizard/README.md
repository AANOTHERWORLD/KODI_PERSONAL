# AANOTHERWORLD Wizard (Kodi program add-on)

A minimal self-updating build wizard for Kodi. It reads a remote manifest, downloads your build ZIP (hosted on GitHub), verifies MD5, and extracts it into Kodi.

## Defaults
- **Manifest URL**: https://raw.githubusercontent.com/AANOTHERWORLD/kodi_personal/main/wizard/manifest.json
- **Build ZIP fallback**: https://github.com/AANOTHERWORLD/kodi_personal/archive/refs/heads/main.zip

You can change both in the add-on settings.

## Install
1. Download the ZIP from this chat.
2. In Kodi: *Settings → Add-ons → Install from zip file* and pick the ZIP.
3. Open **AANOTHERWORLD Wizard** under *Program add-ons*.
4. Choose **Install / Update build**.

## Remote manifest format (upload to your repo at `wizard/manifest.json`)
```json
{
  "version": "1.0.0",
  "zip_url": "https://github.com/AANOTHERWORLD/kodi_personal/archive/refs/heads/main.zip",
  "md5": "", 
  "changelog": "First release."
}
```
- Bump **version** each time you publish an update.
- If you publish release assets, set **zip_url** to the release ZIP.
- Optional **md5** adds an integrity check (recommended for releases).

## Clean vs Merge
- **Merge (safe)**: Extracts over your current setup (default).
- **Clean (advanced)**: Attempts to remove common build paths before extraction. Use with care.

## Logging
The add-on logs messages with the prefix `[AANOTHERWORLD Wizard]` in the Kodi log.
